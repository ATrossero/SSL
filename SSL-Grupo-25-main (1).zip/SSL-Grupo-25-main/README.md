# SSL-Grupo-25
SSL Grupo 25 K2055

## Miembros: 
### Agustin F. Trossero (git: ATrossero)
### Guillermo F. Cacace (git: GFCACACE)
### Manuel F. Gomez Pereyra (git: manugomezp)
### Ignacio Caló (I-Calo)
### Cecilia Majer (ceciliamajer)
